
# Saqib Ahmad's Innovation Blog

This is a personal blog website built with HTML and styled for a clean, modern appearance.

## How to Publish with GitHub Pages

1. Go to [GitHub.com](https://github.com) and create a new repository (public).
2. Upload this folder's contents (`index.html`, `README.md`, etc.) to the repository.
3. Go to the repository Settings > Pages.
4. Under **Source**, choose `main` branch and `/root` folder.
5. Save and your website will be live at:
   `https://yourusername.github.io/your-repo-name/`

---

Created by **Saqib Ahmad**, Master's in Chemistry, Research Innovator.
